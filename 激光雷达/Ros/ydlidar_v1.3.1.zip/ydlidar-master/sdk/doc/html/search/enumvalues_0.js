var searchData=
[
  ['default_5fheart_5fbeat',['DEFAULT_HEART_BEAT',['../classydlidar_1_1_y_dlidar_driver.html#a13a4f2dc4067b43794b2c47c06d5d27aa94033b4717c83f52cd008fe38b712e21',1,'ydlidar::YDlidarDriver']]],
  ['default_5ftimeout',['DEFAULT_TIMEOUT',['../classydlidar_1_1_y_dlidar_driver.html#a13a4f2dc4067b43794b2c47c06d5d27aa07c79ce96f468ff4b40495ef84584442',1,'ydlidar::YDlidarDriver']]]
];
